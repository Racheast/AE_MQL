@SuppressWarnings("all")
public class Tutorial {
  public Object myMethod() throws Throwable {
    return null;
  }
}
